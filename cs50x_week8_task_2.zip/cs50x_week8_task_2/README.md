# cs50x week8 task 2 (landing page)

Task resolution process:

- Fork the repo
- Clone the forked repo to your local machine
- Resolve the task
- Commit your solution
- Push to GitHub
- Create a pull request

Task :
As you learn this week most of the HTML & CSS tags through our class you have a task to solve. You can must design a landing page exactly the same as the XD file [here](https://drive.google.com/file/d/1kZOfBjBpE067aTgEeYj3kXmUopuu6rF9/view?usp=sharing) 

Good luck
